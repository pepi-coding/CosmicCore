import { B } from '../config/balance';
import { evolutions } from '../content/content';
export type PlayerProfile = { schemaVersion: 1; id: string; displayName: string; maximumMass: number; evolutionId: string; unlockedEvolutionIds: string[]; statistics: Record<string, number> };
export interface ProfileStore { load(): PlayerProfile; save(profile: PlayerProfile): boolean }
export const newProfile = (): PlayerProfile => ({ schemaVersion: 1, id: 'local-core', displayName: 'Wanderer', maximumMass: B.mass.initial, evolutionId: 'core', unlockedEvolutionIds: ['core'], statistics: {} });
export function deathLoss(mass: number, floor: number): number { return Math.max(0, Math.min(mass * B.progression.deathPercent, B.progression.deathCap, mass - floor)); }
export function settle(profile: PlayerProfile, won: boolean, unbanked: number, allowBank = true): { banked: number; lost: number } {
  const banked = won && allowBank ? unbanked * B.progression.bankShare : 0;
  const floor = evolutions.find(e => e.id === profile.evolutionId)?.floor ?? B.mass.minimum;
  const lost = won ? 0 : deathLoss(profile.maximumMass, floor);
  profile.maximumMass += banked - lost;
  const key = won ? 'wins' : 'losses'; profile.statistics[key] = (profile.statistics[key] ?? 0) + 1;
  return { banked, lost };
}
export class LocalProfileStore implements ProfileStore {
  static key = 'cosmic-core.profile.v1';
  load(): PlayerProfile {
    try {
      const p: unknown = JSON.parse(localStorage.getItem(LocalProfileStore.key) ?? 'null');
      if (p && typeof p === 'object' && 'schemaVersion' in p && p.schemaVersion === 1 && 'maximumMass' in p && typeof p.maximumMass === 'number' && Number.isFinite(p.maximumMass) && p.maximumMass >= B.mass.minimum) {
        const raw = p as PlayerProfile, clean = newProfile(); clean.maximumMass = raw.maximumMass;
        // Only the basic Core is playable. Unknown schema/content cannot unlock future gameplay.
        if (raw.statistics && typeof raw.statistics === 'object') for (const [k, v] of Object.entries(raw.statistics)) if (Number.isFinite(v) && v >= 0) clean.statistics[k] = v;
        return clean;
      }
    } catch { /* Storage may be blocked or corrupt; the session remains playable. */ }
    return newProfile();
  }
  save(profile: PlayerProfile): boolean { try { localStorage.setItem(LocalProfileStore.key, JSON.stringify(profile)); return true; } catch { return false; } }
}
