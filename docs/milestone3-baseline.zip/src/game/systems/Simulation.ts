import { B } from '../config/balance';
import { arenaContent as map, asteroidAt } from '../content/arena';
import { divisionFor } from '../content/content';
import { createMass, redistribute, recover, eject } from './MassSystem';
import { fieldRadius, gravity } from './GravitySystem';
import { orbit, release, tryCapture } from './OrbitSystem';
import { damage } from './DamageSystem';
import { tickStability, timeout } from './StabilitySystem';
import { abilities } from './AbilitySystem';
import { clamp, distance, seeded, unit, type Actions, type Actor, type Debris, type Kind, type Mode, type Result } from './types';

export class Simulation {
  actors: Actor[] = []; debris: Debris[] = []; time = 0; phase = 0; nextSpawn = 0; suddenDeath = false;
  result: Result | null = null; random: () => number; nextId = 1; killed = new Set<number>(); trainingEngaged = false;
  effects: { x: number; y: number; radius: number; life: number; hostile: boolean }[] = [];
  readonly player: Actor; readonly effectiveMass: number;
  constructor(public mode: Mode, public maximumMass: number, seed = B.seed) {
    this.random = seeded(seed);
    this.effectiveMass = mode === 'pvp' ? Math.min(maximumMass, divisionFor(maximumMass).ceiling) : maximumMass;
    this.player = this.actor('player', B.arena / 2, B.arena / 2, this.effectiveMass * (mode === 'pve' ? B.pve.safeMass : 1));
    if (mode !== 'pve') this.actor('bot', B.arena / 2 + B.bot.startDistance, B.arena / 2, this.effectiveMass);
    for (let i = 0; i < B.visuals.debrisCount; i++) {
      const angle = this.random() * Math.PI * 2, radius = i < B.debris.initialNearCount ? B.debris.nearMin + this.random() * B.debris.nearSpread : B.debris.farMin + this.random() * B.debris.farSpread;
      this.debris.push(this.makeDebris(this.player.x + Math.cos(angle) * radius, this.player.y + Math.sin(angle) * radius, B.mass.debris, true));
    }
    if (mode === 'pve') this.wave(0);
  }
  actor(kind: Kind, x: number, y: number, mass: number): Actor {
    const a: Actor = { id: this.nextId++, kind, x, y, vx: 0, vy: 0, mass: createMass(kind === 'player' ? this.maximumMass : mass, mass), stability: { phase: 'stable', unstableRemainingMs: 0, instabilityCount: 0, trauma: 0 }, targetDistribution: .5, radius: fieldRadius(.5), cooldown: { cast: 0, impulse: 0, pulse: 0, surge: 0, contact: 0 }, surge: 0, recovery: 0, stagger: 0, cap: mass * B.mass.cap, angle: 0, alive: true };
    this.actors.push(a); return a;
  }
  makeDebris(x: number, y: number, mass: number, fresh = false): Debris {
    const angle = this.random() * Math.PI * 2;
    return { id: this.nextId++, x, y, vx: Math.cos(angle) * B.debris.driftSpeed, vy: Math.sin(angle) * B.debris.driftSpeed, mass, owner: null, previousOwner: null, capture: {}, life: fresh ? Infinity : B.mass.fragmentLife, angle, projectile: false, damage: 0, launchOwner: null, fresh };
  }
  fragment(a: Actor, mass: number): Debris {
    const angle = this.random() * Math.PI * 2;
    const d = this.makeDebris(a.x + Math.cos(angle) * B.combat.fragmentOffset, a.y + Math.sin(angle) * B.combat.fragmentOffset, mass);
    d.previousOwner = a.id; d.vx = Math.cos(angle) * B.combat.fragmentSpeed; d.vy = Math.sin(angle) * B.combat.fragmentSpeed; this.debris.push(d); return d;
  }
  hit(a: Actor, amount: number, direct: boolean): void { const removed = damage(a, amount, direct); if (removed > 0) this.fragment(a, removed); }
  pulseVisual(a: Actor): void { this.effects.push({ x: a.x, y: a.y, radius: a.radius, life: .5, hostile: a.id !== this.player.id }); }
  botActions(a: Actor): Actions {
    const target = this.player, delta = { x: target.x - a.x, y: target.y - a.y }, dist = Math.hypot(delta.x, delta.y), n = unit(delta);
    if (this.mode === 'training' && !this.trainingEngaged) return { move: { x: 0, y: 0 }, aim: delta, distribution: .5, cast: false, impulse: false, pulse: false, surge: false };
    let preferred = a.kind === 'drifter' ? 0 : a.kind === 'leech' ? target.radius * B.bot.leechRadius : B.bot.preferredDistance;
    if (a.kind === 'guardian') preferred = Math.sin(this.time / B.enemy.guardianCycle * Math.PI) > 0 ? B.bot.guardianNear : B.bot.guardianFar;
    const move = dist > preferred + B.bot.rangeSlack ? n : dist < preferred - B.bot.rangeSlack ? { x: -n.x, y: -n.y } : { x: -n.y, y: n.x };
    const error = Math.sin(this.time * B.bot.aimFrequency + a.id) * B.bot.aimError;
    const aim = { x: delta.x + target.vx * B.bot.lead + error * dist, y: delta.y + target.vy * B.bot.lead - error * dist };
    const distribution = a.kind === 'drifter' ? B.bot.drifterDistribution : a.kind === 'leech' ? B.bot.leechDistribution : a.kind === 'guardian' ? (Math.sin(this.time / B.enemy.guardianCycle * Math.PI) > 0 ? B.bot.dense : B.bot.wide) : Math.sin(this.time / B.bot.changeDistribution + a.id) > 0 ? B.bot.dense : B.bot.wide;
    return { move: { x: move.x * B.bot.thrust, y: move.y * B.bot.thrust }, aim, distribution, cast: a.kind !== 'drifter' && a.kind !== 'leech' && dist < B.bot.castRange, impulse: dist < B.bot.evadeDistance && a.kind !== 'drifter', pulse: dist < a.radius * B.bot.pulseRange && a.kind !== 'leech', surge: dist < B.bot.surgeRange && (a.kind === 'guardian' || a.kind === 'bot') };
  }
  step(input: Actions, dt = B.step): void {
    if (this.result) return;
    if (input.cast || input.pulse) this.trainingEngaged = true;
    this.time += dt;
    for (const a of this.actors) {
      if (!a.alive) continue;
      const action = a === this.player ? input : this.botActions(a);
      for (const key of Object.keys(a.cooldown) as (keyof Actor['cooldown'])[]) a.cooldown[key] = Math.max(0, a.cooldown[key] - dt);
      a.stagger = Math.max(0, a.stagger - dt); a.recovery = Math.max(0, a.recovery - dt);
      if (a.surge > 0) { a.surge -= dt; if (a.surge <= 0) a.recovery = B.abilities.recoveryDuration; }
      a.targetDistribution = action.distribution;
      redistribute(a.mass, a.surge > 0 ? 1 : a.targetDistribution, dt, a.surge > 0 ? B.abilities.surgeRate : a.recovery > 0 ? B.abilities.recoveryRate : 1);
      a.radius = fieldRadius(a.mass.distribution);
      const accel = B.movement.thrust * (1 - a.mass.distribution * B.movement.inertia) * (a === this.player ? 1 : B.enemy.speed) * (a.stagger > 0 ? B.movement.staggerMultiplier : 1);
      a.vx += action.move.x * accel * dt; a.vy += action.move.y * accel * dt;
      for (const other of this.actors) if (other !== a && other.alive) { const f = gravity(other, a, a.mass.combatMass); a.vx += f.x * dt * B.gravity.entityScale * (1 - a.mass.distribution * B.movement.inertia); a.vy += f.y * dt * B.gravity.entityScale * (1 - a.mass.distribution * B.movement.inertia); }
      a.vx *= Math.exp(-B.movement.drag * dt); a.vy *= Math.exp(-B.movement.drag * dt);
      const speed = Math.hypot(a.vx, a.vy); if (speed > B.movement.speed) { const limit = Math.max(B.movement.speed, speed * Math.exp(-dt * B.movement.overspeedDecay)); a.vx *= limit / speed; a.vy *= limit / speed; }
      a.x = clamp(a.x + a.vx * dt, B.movement.boundary, B.arena - B.movement.boundary); a.y = clamp(a.y + a.vy * dt, B.movement.boundary, B.arena - B.movement.boundary);
      const castReady = a.cooldown.cast <= 0;
      abilities(a, action, this);
      if (a !== this.player && action.cast && castReady) a.cooldown.cast = B.bot.actionInterval;
      orbit(a, this.debris, dt); tickStability(a, dt);
    }
    this.moveDebris(dt);
    this.contacts();
    if (this.mode === 'pve') this.mission(dt);
    for (const a of this.actors) if (!a.alive && !this.killed.has(a.id)) {
      this.killed.add(a.id); for (const d of this.debris.filter(d => d.owner === a.id)) release(a, d);
      if (a !== this.player && this.mode === 'pve') this.player.mass.unbankedMass += a.kind === 'guardian' ? B.pve.guardianReward : B.pve.reward;
      this.pulseVisual(a);
    }
    if (!this.player.alive) this.finish(false, 'Your Core collapsed');
    if (this.mode === 'pvp') {
      const opponent = this.actors[1];
      if (!opponent.alive) this.finish(true, 'Rival Core collapsed');
      else if (this.time >= B.pvp.duration && !this.suddenDeath) { const winner = timeout(this.player, opponent); if (winner !== null) this.finish(winner === this.player.id, 'Time limit · stability tiebreak'); else this.suddenDeath = true; }
      if (this.suddenDeath) for (const a of [this.player, opponent]) { const amount = eject(a.mass, B.pvp.suddenDeathDrain * dt, false); if (amount > 0) this.fragment(a, amount); a.stability.trauma += B.pvp.suddenDeathDrain * dt * B.pvp.suddenDeathTrauma; }
    }
    this.effects = this.effects.filter(e => (e.life -= dt) > 0);
  }
  moveDebris(dt: number): void {
    const living = this.actors.filter(a => a.alive);
    const counts = new Map(living.map(a => [a.id, this.debris.filter(d => d.owner === a.id).length]));
    for (const d of this.debris) {
      if (d.owner !== null) continue;
      d.life -= dt;
      if (d.life <= 0 && d.projectile) { d.projectile = false; d.launchOwner = null; d.life = B.mass.fragmentLife; }
      if (d.life <= 0) continue;
      for (const a of living) { const f = gravity(a, d, d.mass); d.vx += f.x * dt; d.vy += f.y * dt; }
      d.x += d.vx * dt; d.y += d.vy * dt;
      if (d.x < B.debris.boundary || d.x > B.arena - B.debris.boundary) { d.vx *= -1; d.x = clamp(d.x, B.debris.boundary, B.arena - B.debris.boundary); }
      if (d.y < B.debris.boundary || d.y > B.arena - B.debris.boundary) { d.vy *= -1; d.y = clamp(d.y, B.debris.boundary, B.arena - B.debris.boundary); }
      if (d.projectile) {
        for (const a of living) if (a.id !== d.launchOwner) {
          const dist = distance(a, d);
          if (dist < B.combat.coreRadius + B.combat.hitPadding) { this.hit(a, d.damage * Math.max(B.combat.minVelocityDamage, Math.hypot(d.vx - a.vx, d.vy - a.vy) / B.combat.velocityScale), true); d.projectile = false; d.launchOwner = null; d.life = B.mass.fragmentLife; d.vx *= B.combat.impactRetention; d.vy *= B.combat.impactRetention; break; }
          // A glancing trajectory strips the outer Field, while shots aimed at the Core pass through.
          const speed = Math.hypot(d.vx, d.vy), cross = speed ? Math.abs((a.x - d.x) * d.vy - (a.y - d.y) * d.vx) / speed : 0;
          if (dist < a.radius * B.combat.fieldHitRadius && cross > B.combat.coreRadius + B.combat.hitPadding) { this.hit(a, d.damage * B.combat.glancingMultiplier, false); d.projectile = false; d.launchOwner = null; d.life = B.mass.fragmentLife; break; }
        }
      } else {
        for (const a of living) {
          if (distance(a, d) < B.combat.coreRadius + B.combat.hitPadding) {
            const taken = recover(a.mass, d.mass, a.cap, d.previousOwner !== null && d.previousOwner !== a.id, d.fresh);
            d.mass -= taken; if (d.mass <= .00001) { d.life = 0; break; }
          }
          if (tryCapture(a, d, counts.get(a.id) ?? 0, dt)) { counts.set(a.id, (counts.get(a.id) ?? 0) + 1); break; }
        }
      }
    }
    this.debris = this.debris.filter(d => d.owner !== null || d.life > 0);
  }
  contacts(): void {
    const p = this.player;
    for (const a of this.actors) if (a !== p && a.alive && p.alive && distance(a, p) < B.combat.coreRadius * 2 + B.combat.contactPadding) {
      if (a.cooldown.contact <= 0) { this.hit(p, B.combat.contactDamage * (1 + a.mass.distribution), true); a.cooldown.contact = B.combat.contactCooldown; }
      if (p.cooldown.contact <= 0) { this.hit(a, B.combat.contactDamage * (1 + p.mass.distribution), true); p.cooldown.contact = B.combat.contactCooldown; }
      const n = unit({ x: a.x - p.x, y: a.y - p.y }); a.vx += n.x * B.combat.contactPush; a.vy += n.y * B.combat.contactPush; p.vx -= n.x * B.combat.contactPush; p.vy -= n.y * B.combat.contactPush;
    }
  }
  wave(phase: number): void {
    const kinds: Kind[] = phase === 0 ? ['drifter', 'orbiter'] : phase === 1 ? ['leech', 'wisp', 'orbiter'] : ['guardian'];
    const masses: Record<string, number> = { drifter: B.enemy.drifterMass, orbiter: B.enemy.orbiterMass, leech: B.enemy.leechMass, wisp: B.enemy.wispMass, guardian: B.enemy.guardianMass };
    for (const kind of kinds) {
      if (this.actors.filter(a => a.alive).length > B.pve.maxEnemies) break;
      const angle = this.random() * Math.PI * 2;
      this.actor(kind, clamp(this.player.x + Math.cos(angle) * B.pve.spawnDistance, B.pve.spawnPadding, B.arena - B.pve.spawnPadding), clamp(this.player.y + Math.sin(angle) * B.pve.spawnDistance, B.pve.spawnPadding, B.arena - B.pve.spawnPadding), masses[kind]);
    }
  }
  get missionStage(): string {
    if (this.time < B.pve.waveOneEnd) return '01 / Debris frontier · defeat or bypass the patrol';
    if (this.time < B.pve.waveTwoEnd) return '02 / Hungry orbit · displace Leeches with Q';
    if (this.time < B.pve.hazardEnd || !this.challengeReached) return '03 / Entropy passage · reach the marked beacon';
    const guardian = this.actors.find(a => a.kind === 'guardian');
    if (guardian?.alive) return '04 / Core Guardian · survive capture, punish compression';
    if (this.time < B.pve.extractionAfter) return '05 / Hold out · extraction calibrating';
    return '05 / Extraction ready · enter the green beacon';
  }
  challengeReached = false;
  mission(dt: number): void {
    if (this.time >= B.pve.waveOneEnd && this.phase === 0) { this.phase = 1; this.wave(1); }
    if (this.time >= B.pve.waveTwoEnd && this.phase === 1) this.phase = 2;
    if (this.phase === 2 && distance(this.player, map.beacon) < map.beacon.radius) this.challengeReached = true;
    if (this.time >= B.pve.hazardEnd && this.phase === 2 && this.challengeReached) { this.phase = 3; this.wave(3); }
    if (this.time >= B.pve.deadline) this.finish(false, 'Extraction window closed');
    if (this.time >= B.pve.extractionAfter && this.phase === 3 && !this.actors.some(a => a.kind === 'guardian' && a.alive) && distance(this.player, map.extraction) < map.extraction.radius) this.finish(true, 'Extraction complete');
    for (const a of this.actors) if (a.alive && a !== this.player) {
      if (a.kind === 'leech' && distance(a, this.player) < this.player.radius && distance(a, this.player) > this.player.radius * B.pve.leechInner && a.stagger <= 0) this.player.mass.unbankedMass = Math.max(0, this.player.mass.unbankedMass - B.pve.leechDrain * dt);
      if (a.kind === 'wisp' && distance(a, this.player) < a.radius) for (const d of this.debris) { if (distance(a, d) < a.radius) { if (d.owner === this.player.id && this.random() < dt * B.pve.wispRelease) release(this.player, d); else if (d.owner === null) d.life -= dt * B.pve.entropyDecay; } }
    }
    const p = this.player, well = map.well, n = unit({ x: well.x - p.x, y: well.y - p.y });
    if (distance(p, well) < map.well.radius) { p.vx += n.x * B.pve.wellForce * dt; p.vy += n.y * B.pve.wellForce * dt; }
    if (p.x > map.current.x && p.x < map.current.x + map.current.width && p.y > map.current.y && p.y < map.current.y + map.current.height) p.vx += B.pve.currentForce * dt;
    if (distance(p, map.entropy) < map.entropy.radius) {
      p.stability.trauma += B.pve.hazardDamage * dt;
      for (const d of this.debris) if (d.owner === p.id && this.random() < dt * B.pve.entropyRelease) release(p, d);
    }
    for (const d of this.debris) if (d.owner === null && distance(d, map.entropy) < map.entropy.radius) d.life -= dt * B.pve.entropyDecay;
    const asteroid = asteroidAt(this.time);
    if (distance(p, asteroid) < map.asteroid.radius && p.cooldown.contact <= 0) { this.hit(p, B.pve.hazardDamage, true); p.cooldown.contact = B.combat.contactCooldown; }
  }
  finish(won: boolean, reason: string): void { if (!this.result) this.result = { won, reason, gained: this.player.mass.unbankedMass, banked: 0, lost: 0, duration: this.time }; }
}
