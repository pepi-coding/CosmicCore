import { B } from '../config/balance';
import { eject } from './MassSystem';
import { release } from './OrbitSystem';
import { distance, unit, type Actions, type Actor, type Debris } from './types';
export interface AbilityWorld { debris: Debris[]; actors: Actor[]; fragment(a: Actor, mass: number): Debris; hit(a: Actor, amount: number, direct: boolean): void; pulseVisual(a: Actor): void }
export function abilities(a: Actor, input: Actions, world: AbilityWorld): void {
  const direction = unit(input.aim); a.angle = Math.atan2(direction.y, direction.x);
  if (input.impulse && a.cooldown.impulse <= 0) { a.vx += direction.x * B.movement.impulse; a.vy += direction.y * B.movement.impulse; a.cooldown.impulse = B.abilities.impulse; }
  if (input.surge && a.cooldown.surge <= 0 && a.stagger <= 0) { a.surge = B.abilities.surgeDuration; a.cooldown.surge = B.abilities.surge; }
  if (input.cast && a.cooldown.cast <= 0) {
    let d = world.debris.find(d => d.owner === a.id);
    if (d) { release(a, d); d.damage = d.mass * B.combat.objectDamage; }
    else if (a.mass.fieldMass >= B.combat.shardMass && a.mass.combatMass - B.combat.shardMass >= B.mass.minimum) {
      d = world.fragment(a, eject(a.mass, B.combat.shardMass, false)); d.damage = B.combat.shardDamage;
    }
    if (d) {
      d.x = a.x + direction.x * (B.combat.coreRadius + B.combat.launchOffset); d.y = a.y + direction.y * (B.combat.coreRadius + B.combat.launchOffset);
      d.vx = a.vx + direction.x * B.combat.projectileSpeed; d.vy = a.vy + direction.y * B.combat.projectileSpeed;
      d.projectile = true; d.launchOwner = a.id; d.life = B.combat.projectileLife;
      d.damage *= 1 + a.mass.distribution * B.combat.compressionBonus;
      if (a.surge > 0) d.damage *= 1 + B.combat.compressionBonus;
    }
    a.cooldown.cast = B.abilities.cast;
  }
  if (input.pulse && a.cooldown.pulse <= 0 && a.mass.fieldMass >= B.abilities.pulseCost && a.mass.combatMass - B.abilities.pulseCost >= B.mass.minimum) {
    world.fragment(a, eject(a.mass, B.abilities.pulseCost, false));
    world.pulseVisual(a);
    for (const other of world.actors) if (other.id !== a.id && other.alive && distance(a, other) < a.radius) {
      const n = unit({ x: other.x - a.x, y: other.y - a.y });
      const force = B.abilities.pulseForce * (1 + a.mass.distribution) * (1 - other.mass.distribution * B.movement.inertia);
      other.vx += n.x * force; other.vy += n.y * force; other.stagger = B.combat.stagger;
      if (other.surge > 0) { other.surge = 0; other.recovery = B.abilities.recoveryDuration; }
      world.hit(other, B.abilities.pulseDamage * (1 + a.mass.distribution), false);
    }
    for (const d of world.debris) if (d.owner === null && !d.projectile && distance(a, d) < a.radius) { const n = unit({ x: d.x - a.x, y: d.y - a.y }); d.vx += n.x * B.abilities.pulseForce; d.vy += n.y * B.abilities.pulseForce; }
    a.cooldown.pulse = B.abilities.pulse;
  }
}
