export type Vec = { x: number; y: number };
export type MassState = { maximumMass: number; combatMass: number; coreMass: number; fieldMass: number; orbitingStoredMass: number; unbankedMass: number; distribution: number };
export type StabilityState = { phase: 'stable' | 'unstable' | 'collapsed'; unstableRemainingMs: number; instabilityCount: number; trauma: number };
export type Actions = { move: Vec; aim: Vec; distribution: number; cast: boolean; impulse: boolean; pulse: boolean; surge: boolean };
export type Kind = 'player' | 'bot' | 'drifter' | 'orbiter' | 'leech' | 'wisp' | 'guardian';
export type Actor = Vec & { id: number; kind: Kind; vx: number; vy: number; mass: MassState; stability: StabilityState; targetDistribution: number; radius: number; cooldown: Record<'cast' | 'impulse' | 'pulse' | 'surge' | 'contact', number>; surge: number; recovery: number; stagger: number; cap: number; angle: number; alive: boolean };
export type Debris = Vec & { id: number; vx: number; vy: number; mass: number; owner: number | null; previousOwner: number | null; capture: Record<number, number>; life: number; angle: number; projectile: boolean; damage: number; launchOwner: number | null; fresh: boolean };
export type Mode = 'training' | 'pve' | 'pvp';
export type Result = { won: boolean; reason: string; gained: number; banked: number; lost: number; duration: number };
export const clamp = (v: number, min: number, max: number) => Math.max(min, Math.min(max, v));
export const distance = (a: Vec, b: Vec) => Math.hypot(a.x - b.x, a.y - b.y);
export const unit = (v: Vec): Vec => { const length = Math.hypot(v.x, v.y); return length ? { x: v.x / length, y: v.y / length } : { x: 1, y: 0 }; };
export function seeded(seed: number): () => number { return () => { seed |= 0; seed = seed + 0x6D2B79F5 | 0; let t = Math.imul(seed ^ seed >>> 15, 1 | seed); t = t + Math.imul(t ^ t >>> 7, 61 | t) ^ t; return ((t ^ t >>> 14) >>> 0) / 4294967296; }; }
