import Phaser from 'phaser';
import { B, validateBalance } from '../config/balance';
import { divisionFor } from '../content/content';
import { arenaContent as map, asteroidAt } from '../content/arena';
import { ActionInput } from '../input/ActionInput';
import { LocalProfileStore, settle } from '../persistence/Profile';
import { Simulation } from '../systems/Simulation';
import { protectedMass } from '../systems/StabilitySystem';
import { slots } from '../systems/OrbitSystem';
import { seeded, type Mode, type Result } from '../systems/types';

const ui = () => document.querySelector<HTMLDivElement>('#ui')!;
const store = new LocalProfileStore();
const clock = (seconds: number) => `${Math.floor(seconds / 60)}:${String(Math.floor(seconds % 60)).padStart(2, '0')}`;
const sceneFor = { training: 'TrainingScene', pve: 'PvEMissionScene', pvp: 'PvPArenaScene' };
function backdrop(scene: Phaser.Scene): void {
  const g = scene.add.graphics(), random = seeded(B.seed);
  g.fillStyle(0x080c19); g.fillRect(0, 0, 4000, 3000);
  for (let i = 0; i < 230; i++) { g.fillStyle(i % 5 === 0 ? 0x9bbdd1 : 0x647188, random() * .5 + .1); g.fillCircle(random() * 2000, random() * 1200, random() * 1.6 + .4); }
  for (let r = 320; r > 0; r -= 12) { g.fillStyle(0x237e80, .014); g.fillCircle(1000, 500, r); }
  g.lineStyle(1, 0x74dec9, .18); g.strokeCircle(1000, 500, 190); g.strokeEllipse(1000, 500, 520, 170);
  g.fillStyle(0x91ffe3); g.fillCircle(1000, 500, 22);
}
export class BootScene extends Phaser.Scene {
  constructor() { super('BootScene'); }
  create(): void { validateBalance(); this.scene.start('MainMenuScene'); }
}
export class MainMenuScene extends Phaser.Scene {
  constructor() { super('MainMenuScene'); }
  create(): void {
    backdrop(this); const profile = store.load();
    ui().innerHTML = `<main class="menu"><header><a class="brand">◈ <span>COSMIC CORE</span></a><span class="version">LOCAL VERTICAL SLICE / 0.1</span></header><section class="hero"><div class="eyebrow"><span class="dot"></span> A SMALL CORE. AN UNLIMITED COSMOS.</div><h1>Make space.<br><em>Become mass.</em></h1><p>Expand to capture. Compress to strike.<br>Everything you gather is everything you stand to lose.</p><div class="profile"><div class="core-icon">✦</div><div><small>YOUR CORE / ${divisionFor(profile.maximumMass).name.toUpperCase()}</small><strong>${profile.maximumMass.toFixed(1)} <span>MAXIMUM MASS</span></strong></div><span class="saved">● LOCAL PROFILE</span></div></section><nav class="modes"><button data-mode="training"><span class="mode-no">01 / LEARN THE PULL</span><strong>Training sandbox <b>↗</b></strong><span>Find your orbit. Master your distribution.</span><small>FREE EXPLORATION · NO PROGRESSION RISK</small></button><button data-mode="pve" class="featured"><span class="mode-no">02 / GATHER & RETURN</span><strong>Into the frontier <b>↗</b></strong><span>Survive the patrols. Break the Guardian. Extract.</span><small>SOLO MISSION · 5–8 MINUTES</small></button><button data-mode="pvp"><span class="mode-no">03 / CORE AGAINST CORE</span><strong>Orbital duel <b>↗</b></strong><span>Control the field against a deterministic rival.</span><small>LOCAL BOT · 1V1 · 4 MINUTES</small></button></nav><footer><span>WASD move <i>·</i> SHIFT compress <i>·</i> CTRL expand <i>·</i> Mouse aim & cast</span><span>◇ Planetary evolution <strong>LOCKED</strong></span></footer></main>`;
    ui().querySelectorAll<HTMLButtonElement>('[data-mode]').forEach(button => button.onclick = () => this.scene.start(sceneFor[button.dataset.mode as Mode]));
  }
}
class ArenaScene extends Phaser.Scene {
  sim!: Simulation; inputActions!: ActionInput; graphics!: Phaser.GameObjects.Graphics; stars!: Phaser.GameObjects.Graphics;
  accumulator = 0; hudTimer = 0; finished = false; paused = false; debug = false; sprites = new Map<number, Phaser.GameObjects.Zone>();
  constructor(key: string, private mode: Mode) { super(key); }
  create(): void {
    this.accumulator = 0; this.hudTimer = 0; this.finished = false; this.paused = false; this.sprites.clear();
    this.sim = new Simulation(this.mode, store.load().maximumMass);
    this.physics.world.setBounds(0, 0, B.arena, B.arena);
    // Arcade bodies mirror the fixed-step model for collision/debug integration. Forces and authoritative state remain pure.
    this.graphics = this.add.graphics();
    this.stars = this.add.graphics().setDepth(-1); const random = seeded(B.seed);
    for (let i = 0; i < B.visuals.stars; i++) { this.stars.fillStyle(0x8ca3be, .2 + random() * .45); this.stars.fillCircle(random() * B.arena, random() * B.arena, .6 + random()); }
    this.cameras.main.setBackgroundColor('#080c19');
    this.inputActions = new ActionInput(this.game.canvas);
    ui().innerHTML = `<div class="hud"><header class="hud-top"><div class="hud-title"><span class="brand">◈ COSMIC CORE</span><small>${this.mode === 'pve' ? 'FRONTIER / SOLO MISSION' : this.mode === 'pvp' ? `LOCAL BOT DUEL / ${divisionFor(this.sim.maximumMass).name.toUpperCase()}` : 'TRAINING / NO PROGRESSION RISK'}</small></div><div id="objective"></div><button id="pause" class="quiet">Ⅱ Pause</button><button id="exit" class="quiet">Exit ↗</button></header><div class="mass-panel"><small>CONTROLLED MASS</small><strong id="mass-value"></strong><div class="distribution"><i id="core-meter"></i><i id="field-meter"></i></div><div class="split-label"><span id="core-value"></span><span id="field-value"></span></div><div id="stability"></div><div id="bank"></div></div><div id="rival"></div><div class="mission-note" id="mission-note"></div><div class="ability-bar"><button data-action="impulse"><kbd>SPACE</kbd><span>↗ Impulse</span><small id="cd-impulse">READY</small></button><button data-action="pulse"><kbd>Q</kbd><span>◎ Mass pulse</span><small id="cd-pulse">READY</small></button><button data-action="surge"><kbd>E</kbd><span>✦ Surge</span><small id="cd-surge">READY</small></button></div><div class="desktop-hints">WASD <span>thrust</span> · Mouse <span>cast</span> · SHIFT <span>compress</span> · CTRL <span>expand</span><button id="reset">Reset training</button><button id="debug">Telemetry</button></div><div class="touch-controls"><div class="stick" data-stick="move"><i></i><span>THRUST</span></div><div class="redistribute"><button data-action="expand">⊕ Expand</button><button data-action="compress">⊙ Compress</button></div><div class="stick" data-stick="aim"><i></i><span>AIM / CAST</span></div></div><pre id="debug-panel" hidden></pre><div id="pause-overlay" hidden><h2>Orbit paused</h2><p>Resume when you’re ready.</p><button id="resume">Resume →</button></div></div>`;
    this.inputActions.attachTouch(ui());
    if (this.mode !== 'training') {
      const exit = ui().querySelector<HTMLButtonElement>('#exit')!;
      exit.textContent = 'Abandon ↗'; exit.title = 'Lose unbanked run mass and apply the protected 1% permanent penalty.';
    }
    ui().querySelector<HTMLButtonElement>('#exit')!.onclick = () => { if (this.mode === 'training') this.scene.start('MainMenuScene'); else { this.sim.finish(false, 'Run abandoned'); this.complete(); } };
    ui().querySelector<HTMLButtonElement>('#pause')!.onclick = () => this.togglePause();
    ui().querySelector<HTMLButtonElement>('#resume')!.onclick = () => this.togglePause();
    ui().querySelector<HTMLButtonElement>('#reset')!.hidden = this.mode !== 'training';
    ui().querySelector<HTMLButtonElement>('#reset')!.onclick = () => this.scene.restart();
    ui().querySelector<HTMLButtonElement>('#debug')!.onclick = () => { this.debug = !this.debug; };
    const blur = () => { if (!this.paused) this.togglePause(); }; window.addEventListener('blur', blur);
    this.events.once(Phaser.Scenes.Events.SHUTDOWN, () => { this.inputActions.destroy(); window.removeEventListener('blur', blur); });
    this.updateHUD();
  }
  togglePause(): void { this.paused = !this.paused; this.inputActions.clear(); ui().querySelector<HTMLElement>('#pause-overlay')!.hidden = !this.paused; }
  update(_time: number, delta: number): void {
    if (this.finished) return;
    const portrait = matchMedia('(pointer: coarse) and (orientation: portrait)').matches;
    if (!this.paused && !portrait) {
      this.accumulator += Math.min(delta / 1000, B.step * B.maxSteps);
      while (this.accumulator >= B.step) { this.sim.step(this.inputActions.sample({ x: this.scale.width / 2, y: this.scale.height / 2 }, B.step)); this.accumulator -= B.step; }
    }
    this.renderWorld();
    this.hudTimer += delta / 1000; if (this.hudTimer >= B.visuals.hudInterval) { this.hudTimer = 0; this.updateHUD(); }
    if (this.sim.result) this.complete();
  }
  complete(): void {
    if (this.finished || !this.sim.result) return; this.finished = true;
    const result = this.sim.result, profile = store.load(); let saved = true;
    if (this.mode !== 'training') { Object.assign(result, settle(profile, result.won, result.gained, this.mode === 'pve')); saved = store.save(profile); }
    this.scene.start('ResultsScene', { result, mode: this.mode, saved });
  }
  renderWorld(): void {
    const g = this.graphics, p = this.sim.player, cam = this.cameras.main;
    const desired = Phaser.Math.Clamp(Math.min(this.scale.width * .68, this.scale.height * .75) / (p.radius * 2 + 80), B.visuals.zoomMin, B.visuals.zoomMax);
    cam.setZoom(Phaser.Math.Linear(cam.zoom, desired, .04)); cam.centerOn(p.x, p.y);
    g.clear(); g.lineStyle(2, 0x364965, .5); g.strokeRect(20, 20, B.arena - 40, B.arena - 40);
    g.lineStyle(1, 0x22314b, .23); for (let i = 0; i <= B.arena; i += 100) { g.lineBetween(i, 0, i, B.arena); g.lineBetween(0, i, B.arena, i); }
    if (this.mode === 'pve') {
      const { entropy, well, current, extraction, beacon } = map;
      g.fillStyle(0x994de0, .12); g.fillCircle(entropy.x, entropy.y, entropy.radius); g.lineStyle(2, 0xaf71e3, .4); g.strokeCircle(entropy.x, entropy.y, entropy.radius);
      g.lineStyle(2, 0x6598e8, .35); for (let r = 40; r <= well.radius; r += 40) g.strokeCircle(well.x, well.y, r);
      g.fillStyle(0x297dad, .09); g.fillRect(current.x, current.y, current.width, current.height);
      g.lineStyle(2, 0x5fbcdf, .3); for (let x = current.x + 30; x < current.x + current.width - 30; x += 70) { const y = current.y + current.height / 2; g.lineBetween(x, y, x + 25, y); g.lineBetween(x + 15, y - 10, x + 25, y); }
      g.fillStyle(0x9da7b2); const asteroid = asteroidAt(this.sim.time); g.fillCircle(asteroid.x, asteroid.y, map.asteroid.radius * .62); g.lineStyle(2, 0xf6c38a, .6); g.strokeCircle(asteroid.x, asteroid.y, map.asteroid.radius);
      g.lineStyle(3, 0x85faab, .7); g.strokeCircle(extraction.x, extraction.y, extraction.radius); g.lineBetween(extraction.x - 20, extraction.y, extraction.x + 20, extraction.y); g.lineBetween(extraction.x, extraction.y - 20, extraction.x, extraction.y + 20);
      if (!this.sim.challengeReached) { g.lineStyle(2, 0xd5a3ff); g.strokeCircle(beacon.x, beacon.y, beacon.radius); }
      // Off-screen objective direction stays visible in the player's vicinity.
      const target = !this.sim.challengeReached && this.sim.phase >= 2 ? map.beacon : this.sim.phase >= 3 ? this.sim.actors.find(a => a.kind === 'guardian' && a.alive) ?? map.extraction : null;
      if (target) { const angle = Math.atan2(target.y - p.y, target.x - p.x), r = p.radius + 28; g.lineStyle(4, 0xbcefa8); g.lineBetween(p.x + Math.cos(angle) * r, p.y + Math.sin(angle) * r, p.x + Math.cos(angle) * (r + 25), p.y + Math.sin(angle) * (r + 25)); }
    }
    for (const a of this.sim.actors) {
      if (!a.alive) continue;
      const friendly = a === p, color = friendly ? 0x76efce : a.kind === 'guardian' ? 0xffc276 : 0xf67a8e;
      g.fillStyle(color, .035 + a.mass.distribution * .035); g.fillCircle(a.x, a.y, a.radius);
      g.lineStyle(1.5, color, .45); g.strokeCircle(a.x, a.y, a.radius);
      g.lineStyle(1, color, .13); g.strokeCircle(a.x, a.y, a.radius * .52);
      const radius = B.combat.coreRadius + a.mass.distribution * 5;
      for (let i = 4; i > 0; i--) { g.fillStyle(color, .035); g.fillCircle(a.x, a.y, radius + i * 8); }
      if (a.stability.phase === 'unstable') { g.lineStyle(4, 0xffffff, .5 + Math.sin(this.sim.time * 16) * .45); g.strokeCircle(a.x, a.y, radius + 12); g.lineStyle(2, 0xff5069, .9); g.strokeCircle(a.x, a.y, radius + 25); }
      if (a.surge > 0) { g.lineStyle(4, 0xffdc96); g.strokeCircle(a.x, a.y, radius + 20 + Math.sin(this.sim.time * 14) * 5); }
      g.fillStyle(color, .9); g.fillCircle(a.x, a.y, radius);
      g.fillStyle(0xf1fff9); g.fillCircle(a.x - 3, a.y - 3, radius * .45);
      g.lineStyle(2, color, friendly ? .8 : .5); g.lineBetween(a.x + Math.cos(a.angle) * (radius + 8), a.y + Math.sin(a.angle) * (radius + 8), a.x + Math.cos(a.angle) * (radius + 30), a.y + Math.sin(a.angle) * (radius + 30));
      if (!this.sprites.has(a.id)) { const zone = this.add.zone(a.x, a.y, radius * 2, radius * 2); this.physics.add.existing(zone); (zone.body as Phaser.Physics.Arcade.Body).moves = false; this.sprites.set(a.id, zone); }
      const zone = this.sprites.get(a.id)!; zone.setPosition(a.x, a.y); (zone.body as Phaser.Physics.Arcade.Body).reset(a.x, a.y);
    }
    for (const d of this.sim.debris) {
      const color = d.owner === p.id ? 0x9bffe0 : d.owner !== null ? 0xff829b : d.previousOwner !== null ? 0xffd795 : 0xb4c8de;
      if (d.projectile) { g.lineStyle(3, color, .45); g.lineBetween(d.x, d.y, d.x - d.vx * .04, d.y - d.vy * .04); }
      g.fillStyle(color, d.life < 3 ? .4 : .95); const size = Math.min(9, 3 + Math.sqrt(d.mass)); g.fillRect(d.x - size / 2, d.y - size / 2, size, size);
      if (Object.values(d.capture).some(v => v > 0)) { g.lineStyle(1, 0xffdc96, .8); g.strokeCircle(d.x, d.y, size + 4); }
    }
    for (const e of this.sim.effects) { g.lineStyle(3, e.hostile ? 0xff8099 : 0xa0ffdc, e.life * 1.6); g.strokeCircle(e.x, e.y, e.radius * (1 - e.life)); }
  }
  updateHUD(): void {
    const p = this.sim.player, m = p.mass, text = (id: string, value: string) => { ui().querySelector<HTMLElement>(`#${id}`)!.textContent = value; };
    text('mass-value', m.combatMass.toFixed(1)); text('core-value', `${m.coreMass.toFixed(0)} CORE`); text('field-value', `${m.fieldMass.toFixed(0)} FIELD`);
    ui().querySelector<HTMLElement>('#core-meter')!.style.width = `${m.coreMass / Math.max(1, m.combatMass) * 100}%`;
    ui().querySelector<HTMLElement>('#field-meter')!.style.width = `${m.fieldMass / Math.max(1, m.combatMass) * 100}%`;
    text('stability', p.stability.phase === 'unstable' ? `⚠ CORE EXPOSED · ${(p.stability.unstableRemainingMs / 1000).toFixed(1)}s` : '● CORE STABLE');
    ui().querySelector<HTMLElement>('#stability')!.className = p.stability.phase;
    text('bank', this.mode === 'pve' ? `◇ ${m.unbankedMass.toFixed(1)} unbanked mass` : `${this.sim.debris.filter(d => d.owner === p.id).length} / ${slots(p)} orbits · ${m.orbitingStoredMass.toFixed(1)} stored`);
    text('objective', this.mode === 'pvp' ? this.sim.suddenDeath ? 'SUDDEN DEATH' : clock(Math.max(0, B.pvp.duration - this.sim.time)) : clock(this.sim.time));
    text('mission-note', this.mode === 'pve' ? this.sim.missionStage : this.mode === 'training' ? this.sim.trainingEngaged ? 'Expose the rival Core, then land a finishing hit. Reset to return to practice.' : 'Expand to catch debris. Cast or pulse to activate the training rival.' : `EFFECTIVE MASS ${this.sim.effectiveMass.toFixed(1)} · BOT SIMULATION`);
    const rival = this.sim.actors.find(a => a !== p && a.alive);
    text('rival', rival ? `${rival.kind.toUpperCase()} / ${rival.stability.phase.toUpperCase()} · ${rival.mass.combatMass.toFixed(0)} MASS` : 'FIELD CLEAR');
    for (const key of ['impulse', 'pulse', 'surge'] as const) text(`cd-${key}`, p.cooldown[key] > 0 ? `${p.cooldown[key].toFixed(1)}s` : key === 'pulse' && m.fieldMass < B.abilities.pulseCost ? 'LOW FIELD MASS' : 'READY');
    const debug = ui().querySelector<HTMLElement>('#debug-panel')!; debug.hidden = !this.debug;
    debug.textContent = `FPS ${this.game.loop.actualFps.toFixed(0)} | fixed ${1 / B.step}Hz\ndistribution ${m.distribution.toFixed(3)} | protected ${protectedMass(p).toFixed(1)}\nmass error ${(m.combatMass - m.coreMass - m.fieldMass - m.orbitingStoredMass).toFixed(8)}\nseed ${B.seed} | bodies ${this.sim.actors.length} | debris ${this.sim.debris.length}`;
  }
}
export class TrainingScene extends ArenaScene { constructor() { super('TrainingScene', 'training'); } }
export class PvEMissionScene extends ArenaScene { constructor() { super('PvEMissionScene', 'pve'); } }
export class PvPArenaScene extends ArenaScene { constructor() { super('PvPArenaScene', 'pvp'); } }
export class ResultsScene extends Phaser.Scene {
  constructor() { super('ResultsScene'); }
  create(data: { result: Result; mode: Mode; saved: boolean }): void {
    backdrop(this); const { result: r, mode, saved } = data;
    ui().innerHTML = `<main class="results"><div class="eyebrow">${mode === 'pvp' ? 'LOCAL BOT DUEL' : mode.toUpperCase()} / ${clock(r.duration)}</div><h1>${r.won ? 'Core intact.' : 'Into the dust.'}</h1><p>${r.reason}</p><div class="result-grid"><div><small>GATHERED</small><strong>${r.gained.toFixed(1)}</strong></div><div><small>BANKED</small><strong>+${r.banked.toFixed(1)}</strong></div><div><small>PERMANENT LOSS</small><strong>−${r.lost.toFixed(1)}</strong></div></div><p>${!r.won && mode !== 'training' ? `Run mass lost: ${r.gained.toFixed(1)}. Permanent loss is capped and tier protected.` : mode === 'training' ? 'Training does not change your profile.' : mode === 'pvp' ? 'Duel gains are temporary. Earn permanent mass in PvE.' : 'Your gathered mass is now permanent maximum mass.'}</p><div class="result-actions"><button id="again">Play again ↗</button><button id="menu">Return to menu</button></div><small>${saved ? 'LOCAL PROFILE SAVED' : 'SAVE UNAVAILABLE · Browser storage is blocked; progress could not be persisted.'}</small></main>`;
    ui().querySelector<HTMLButtonElement>('#again')!.onclick = () => this.scene.start(sceneFor[mode]); ui().querySelector<HTMLButtonElement>('#menu')!.onclick = () => this.scene.start('MainMenuScene');
  }
}
