import { test, expect } from '@playwright/test';
test('desktop menu, live redistribution, pause, reset, results and local save', async ({ page }) => {
  const errors: string[] = []; page.on('pageerror', e => errors.push(e.message));
  await page.setViewportSize({ width: 1440, height: 900 }); await page.goto('/');
  await expect(page.getByRole('heading', { name: 'Make space. Become mass.' })).toBeVisible();
  await page.screenshot({ path: 'test-results/menu.png' });
  await page.locator('[data-mode="training"]').click(); await expect(page.locator('#stability')).toHaveText('● CORE STABLE');
  await page.getByRole('button', { name: 'Telemetry' }).click();
  await page.keyboard.down('Shift'); await page.waitForTimeout(1600); await page.keyboard.up('Shift');
  await expect(page.locator('#debug-panel')).toContainText('distribution 1.000');
  await page.keyboard.down('Control'); await page.waitForTimeout(1600); await page.keyboard.up('Control');
  await expect(page.locator('#debug-panel')).toContainText('distribution 0.000');
  await page.screenshot({ path: 'test-results/training-desktop.png' });
  await page.getByRole('button', { name: 'Pause', exact: false }).click(); await expect(page.getByRole('heading', { name: 'Orbit paused' })).toBeVisible();
  await page.getByRole('button', { name: 'Resume', exact: false }).click(); await page.getByRole('button', { name: 'Reset training' }).click();
  await page.locator('#exit').click(); await page.locator('[data-mode="pvp"]').click(); await page.locator('#exit').click();
  await expect(page.getByRole('heading', { name: 'Into the dust.' })).toBeVisible();
  await page.locator('#menu').click(); await page.reload(); await expect(page.locator('.profile strong')).toContainText('99.0');
  expect(errors).toEqual([]);
});
test('mobile landscape touch controls and portrait guard', async ({ browser }) => {
  const context = await browser.newContext({ viewport: { width: 844, height: 390 }, isMobile: true, hasTouch: true });
  const page = await context.newPage(); await page.goto('/'); await page.locator('[data-mode="training"]').tap();
  await expect(page.locator('[data-stick="move"]')).toBeVisible(); await expect(page.locator('[data-action="compress"]')).toBeVisible();
  const button = page.locator('[data-action="compress"]');
  await button.dispatchEvent('pointerdown', { pointerId: 1, pointerType: 'touch' }); await page.waitForTimeout(1400); await button.dispatchEvent('pointerup', { pointerId: 1, pointerType: 'touch' });
  await page.screenshot({ path: 'test-results/training-mobile.png' });
  await page.setViewportSize({ width: 390, height: 844 }); await expect(page.locator('#rotate')).toBeVisible(); await context.close();
});
